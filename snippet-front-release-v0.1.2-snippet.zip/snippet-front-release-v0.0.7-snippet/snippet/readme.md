<h1 align="center">SOCIETE GENERALE - Scalexpert</h1>
<p align="center">Snippet code for base integration solution scalexpert</p>
